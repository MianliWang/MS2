﻿MS2人工复核包
==============

范围
----
- 最终结果：final_result/ms2_shadow_untrained.csv（129行）
- 可视化人工复核队列：58条，每条包含PNG和SVG
- 当前数据没有独立ground truth；本包为UNTRAINED feasibility结果，下列阈值是当前经验默认值，不是训练得到的最佳参数。

当前下游判定配置
----------------
- 类型：经验默认阈值
- cosine >= 0.7
- matched fragments >= 6
- 双侧 explained intensity >= 0.5
- entropy threshold：关闭

使用方法
--------
1. 打开 START_HERE.html 浏览全部人工复核图。
2. 在 review_labels.csv 中填写truth_label、confidence、quality和notes；该表已包含
   target_uid、Compound_ID和对应PNG/SVG路径，不应依靠行顺序猜测映射。
3. review_queue.csv 保存自动状态、谱图指标和比较上下文，便于筛选排序。
4. final_result 目录保留完整最终CSV及其参数/provenance metadata。

人工标签词表
------------
- positive_same_compound
- negative_different_or_interference
- uncertain
- not_evaluable

科学边界
--------
这些图只评价两个保留时间位置的MS2证据是否支持同一化合物，不能直接证明
其为对映体，也不进行R/S指认。论文Method参数保持固定，不由本流程训练。
图片显式展示当前自动status、指标和阈值，因此本包适合audit/triage，不是盲法
ground-truth收集包；用于训练前仍需独立盲审和adjudication。
