# MSAI RT10 mzXML2 coverage result package

This package contains the 10-second MS2 rerun for the peak-list slice covered
by `IG_STD500nM_EASMSV1_2.mzXML`, together with the explicit 8-second audit
baseline.

## Included

- `MSAI/peaklist/merged_result_IG_EASMSV1_mzxml2_coverage.csv` and its
  `.slice.json` provenance record;
- `tables/ms2_analysis_rt10.csv` as the primary result and its metadata;
- `tables/ms2_analysis_rt8.csv` as the comparison baseline and its metadata;
- RT8-versus-RT10 comparison CSV/JSON files;
- self-contained manual-review HTML reports;
- 129 primary PNG and 129 primary SVG spectrum-review images;
- 11 status-change PNG and 11 status-change SVG images;
- visualization metadata and annotation templates;
- diagnostic standard v2 and the AdductMLib reference-method profile.

The repeated category `views/` hard links are intentionally omitted to avoid
storing identical images many times. The raw mzXML is also omitted; its path and
SHA256 are recorded in the slice provenance JSON.

The primary run uses `MSAI-MS2-DIAGNOSTIC-v2` and a 10-second configured RT
half-window. Close peak pairs retain the anti-overlap rule
`min(10 seconds, 0.4 * RT separation)`.
