# MS2 static evidence review export

Generated 11 canonical SVG images and matching PNG copies,
including honest diagnostic placeholders for records without spectra. `views/`
contains non-exclusive NTFS hardlink views by MS2 diagnostic status, review
priority, spectrum availability, issue code, acquisition coverage, source
machine, and pool. Open `galleries/index.html` for thumbnail review.

The matching metadata sidecar supplied extraction parameters and acquired DIA windows.

A reference-method profile is shown separately from raw-observed acquisition fields; discrepancies are intentional review warnings.

Copy `annotations/_template/review_labels.csv` to
`annotations/<reviewer>/round_1/labels.csv`; reruns never delete `annotations/`.
Allowed identity labels should remain same-compound support/conflict,
insufficient, not evaluable, or uncertain. This workflow does not assign R/S.
